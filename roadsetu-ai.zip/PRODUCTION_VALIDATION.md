RoadSetu production validation checkpoint.
